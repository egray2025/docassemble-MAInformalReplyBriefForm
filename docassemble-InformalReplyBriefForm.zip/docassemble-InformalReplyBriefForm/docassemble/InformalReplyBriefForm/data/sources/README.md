# Sources directory

This directory is used to store word translation files,
machine learning training files, and other source files.
