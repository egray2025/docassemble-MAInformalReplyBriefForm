# docassemble.InformalReplyBriefForm

Informal reply brief form

## Author

Jack Brandt

